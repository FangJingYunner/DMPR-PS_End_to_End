"""Network model related package."""
from .yolo_model import get_model
# from .cspdarknet import CSPDarkNet